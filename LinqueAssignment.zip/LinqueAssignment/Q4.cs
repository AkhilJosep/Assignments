﻿using LinqueAssignment;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LInQAssignment
{
    //4. For the previous exercise, write a LINQ query that displays the details grouped by the month in the descending order of the order date.
    internal class Q4
    {
        public static void Main(string[] args)
        {
            List<Order> orderlist = new List<Order>()
            {
               new Order {OrderId=101,ItemName="Book",Quantity=1000,OrderDate=new DateTime(2023,4,17),},
                new Order {OrderId=102,ItemName="Ball",Quantity=100,OrderDate=new DateTime(2023,10,25),},
                new Order {OrderId=103,ItemName="Pen",Quantity=500,OrderDate=new DateTime(2023,8,30),},
                new Order {OrderId=104,ItemName="Pencil",Quantity=450,OrderDate=new DateTime(2023,6,30),},
                new Order {OrderId=105,ItemName="Eraser",Quantity=300,OrderDate=new DateTime(2023,12,30)}

            };

            var result = from order1 in orderlist
                         orderby order1.OrderDate descending
                         group order1 by order1.OrderDate.Month;


            Console.WriteLine("Recent to Oldest Order...");


            foreach (var order in result)
            {
                Console.WriteLine($"Order of month:{order.Key}");
                foreach (var item in order)
                {
                    Console.WriteLine(item.ItemName);
                }


            }


        }
    }
}

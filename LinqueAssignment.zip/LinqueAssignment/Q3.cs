﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LinqueAssignment
{
    //3. Create an Order class that has order id, item name, order date and quantity. Create a collection of Order objects.
    //Display the data day wise from most recently ordered to least recently ordered and by quantity from highest to lowest.
    public class Order
    {
        public int OrderId { get; set; }
        public string ItemName { get; set; }
        public DateTime OrderDate { get; set; }
        public int Quantity { get; set; }
    }
    internal class Q3
    {

        public static void Main(string[] args)
        {
            List<Order> orderlist = new List<Order>()
            {
                new Order {OrderId=101,ItemName="Book",Quantity=1000,OrderDate=new DateTime(2023,4,17),},
                new Order {OrderId=102,ItemName="Ball",Quantity=100,OrderDate=new DateTime(2023,10,25),},
                new Order {OrderId=103,ItemName="Pen",Quantity=500,OrderDate=new DateTime(2023,8,30),},
                new Order {OrderId=104,ItemName="Pencil",Quantity=450,OrderDate=new DateTime(2023,6,30),},
                new Order {OrderId=105,ItemName="Eraser",Quantity=300,OrderDate=new DateTime(2023,12,30)}
            };

            var res = from item in orderlist
                         orderby item.OrderDate descending
                         select item;

            Console.WriteLine("Recent to Oldest Order...");


            foreach (var order in res)
            {
                Console.WriteLine($"ID: {order.OrderId} Name:{order.ItemName} Quantity:{order.Quantity} Date:{order.OrderDate}");
            }


            Console.WriteLine("Highest to Lowest Quantity...");

            res = from item in orderlist
                     orderby item.Quantity descending
                     select item;

            foreach (var order in res)
            {
                Console.WriteLine($"ID: {order.OrderId} Name:{order.ItemName} Quantity:{order.Quantity} Date:{order.OrderDate}");
            }
        }


    }
}
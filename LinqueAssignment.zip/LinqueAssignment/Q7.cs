﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LinqueAssignment
{
   // 7. Check if all the quantities in the Order collection is >0.
    internal class Q7
    {
        List<Order>
    }
}
